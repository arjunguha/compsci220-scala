object Lecture1 {

  val oddNumbers = 1 :: 3 :: 5 :: Nil

}